# run_evolving_brain.py

from evolving_brain import EvolvingBrain

brain = EvolvingBrain()

# Perceive environment
brain.perceive("I see fire")
brain.learn_new_concept("fire", ["hot", "red", "dangerous"])
brain.think = brain.reason  # alias for clarity
print(brain.think())
brain.act()

brain.perceive("I see water")
brain.learn_new_concept("water", ["wet", "clear", "safe"])
print(brain.think())
brain.act()

# Reflect on life
brain.reflect()

# Simulate evolution: learning from new experience
new_knowledge = {
    "lava": ["hot", "dangerous", "molten"],
    "ice": ["cold", "solid", "clear"]
}
brain.evolve(new_knowledge)
brain.perceive("I see lava")
print(brain.think())
