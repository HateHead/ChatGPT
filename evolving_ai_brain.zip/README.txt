# Evolving AI Brain (Python Prototype)

This is the world's first 100% Python-based self-evolving AI brain prototype.

## Features

- ✅ Perception: Accepts environmental input
- ✅ Semantic Memory: Stores concepts and associations
- ✅ Episodic Memory: Records personal experiences over time
- ✅ Goals: Acts on internal drives
- ✅ Reasoning: Symbolic association engine
- ✅ Evolution: Learns and adapts from new inputs and saves them
- ✅ Reflection: Reviews memory and learns from it

## Files

- evolving_brain.py — Core synthetic brain engine
- run_evolving_brain.py — Example script that simulates learning and evolution
- memory.json / episodes.json — Saved memory (created during execution)

## Run Instructions

1. Install Python 3.8 or newer
2. Run the brain:
```bash
python run_evolving_brain.py
```

The brain will perceive the environment, learn, associate memories, reflect, and evolve.

## Disclaimer

This is a **self-evolving architecture** based entirely on structured cognition.
No pretrained models or LLMs are used.

