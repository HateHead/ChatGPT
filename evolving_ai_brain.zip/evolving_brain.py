# evolving_brain.py

import json
import os
from datetime import datetime

class SemanticMemory:
    def __init__(self, file_path="memory.json"):
        self.file_path = file_path
        self.knowledge = {}
        self.load()

    def learn(self, concept, attributes):
        self.knowledge[concept] = list(set(attributes))
        self.save()

    def recall(self, concept):
        return self.knowledge.get(concept, "I don't know that.")

    def associate(self, concept):
        results = []
        if concept not in self.knowledge:
            return results
        target_attrs = set(self.knowledge[concept])
        for k, v in self.knowledge.items():
            if k == concept:
                continue
            if target_attrs.intersection(v):
                results.append(k)
        return results

    def save(self):
        with open(self.file_path, "w") as f:
            json.dump(self.knowledge, f, indent=2)

    def load(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, "r") as f:
                self.knowledge = json.load(f)

class EpisodicMemory:
    def __init__(self, file_path="episodes.json"):
        self.file_path = file_path
        self.episodes = []
        self.load()

    def record(self, event):
        timestamp = datetime.now().isoformat()
        self.episodes.append({"time": timestamp, "event": event})
        self.save()

    def recall_recent(self, n=5):
        return self.episodes[-n:]

    def save(self):
        with open(self.file_path, "w") as f:
            json.dump(self.episodes, f, indent=2)

    def load(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, "r") as f:
                self.episodes = json.load(f)

class GoalEngine:
    def __init__(self):
        self.goals = []

    def add_goal(self, goal):
        print(f"[Goal] New goal added: {goal}")
        if goal not in self.goals:
            self.goals.append(goal)

    def next_action(self, memory):
        for goal in self.goals:
            for mem in reversed(memory.episodes):
                if goal in mem["event"]:
                    return f"Act on goal '{goal}' based on memory: {mem['event']}"
        return "No memory matches goals yet."

class EvolvingBrain:
    def __init__(self):
        self.semantic = SemanticMemory()
        self.episodic = EpisodicMemory()
        self.goals = GoalEngine()

    def perceive(self, input_data):
        print(f"[Perception] Observed: {input_data}")
        self.episodic.record(input_data)

    def reason(self):
        last_event = self.episodic.episodes[-1]["event"] if self.episodic.episodes else "nothing"
        associations = self.semantic.associate(last_event)
        if associations:
            return f"I associate '{last_event}' with: {', '.join(associations)}"
        return f"I don't know how to interpret '{last_event}' yet."

    def act(self):
        action = self.goals.next_action(self.episodic)
        print(f"[Action] {action}")

    def learn_new_concept(self, concept, attributes):
        self.semantic.learn(concept, attributes)
        print(f"[Learning] Learned '{concept}' with attributes {attributes}")

    def reflect(self):
        print("[Reflection] Last 5 memories:")
        for ep in self.episodic.recall_recent():
            print(f"  {ep['time']}: {ep['event']}")

    def evolve(self, new_data):
        for concept, attrs in new_data.items():
            self.learn_new_concept(concept, attrs)
